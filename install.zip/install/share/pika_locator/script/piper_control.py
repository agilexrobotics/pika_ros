#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import Header

class PIPER:
    def __init__(self):
        
        # 发布控制piper机械臂话题
        self.pub_joint = rospy.Publisher('/joint_states', JointState, queue_size=10)
        self.left_pub_joint = rospy.Publisher('/left_joint_states', JointState, queue_size=100)
        self.right_pub_joint = rospy.Publisher('/right_joint_states', JointState, queue_size=100)
        
        # self.rate = rospy.Rate(80) # 10hz

    # def init_pose(self):            
    #     joint_states_msgs = JointState()
    #     joint_states_msgs.header = Header()
    #     joint_states_msgs.header.stamp = rospy.Time.now()
    #     joint_states_msgs.name = [f'joint{i+1}' for i in range(7)]
    #     joint_states_msgs.position = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    #     self.pub_joint.publish(joint_states_msgs)
    #     # self.rate.sleep()
    #     print("send joint control piper command")

    # 每次调用都会连续发送2秒的数据
    def init_pose(self):
        start_time = rospy.Time.now()  # 获取当前时间
        while (rospy.Time.now() - start_time).to_sec() < 2.0:  # 持续发送2秒
            joint_states_msgs = JointState()
            joint_states_msgs.header = Header()
            joint_states_msgs.header.stamp = rospy.Time.now()
            joint_states_msgs.name = [f'joint{i+1}' for i in range(7)]
            joint_states_msgs.position = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
            self.pub_joint.publish(joint_states_msgs)
        print("send joint control piper command for 2 seconds")

    def left_init_pose(self):
        joint_states_msgs = JointState()
        joint_states_msgs.header = Header()
        joint_states_msgs.header.stamp = rospy.Time.now()
        joint_states_msgs.name = [f'joint{i+1}' for i in range(7)]
        joint_states_msgs.position = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.left_pub_joint.publish(joint_states_msgs)
        # self.rate.sleep()
        print("send joint control piper command")
        
    def right_init_pose(self):
        joint_states_msgs = JointState()
        joint_states_msgs.header = Header()
        joint_states_msgs.header.stamp = rospy.Time.now()
        joint_states_msgs.name = [f'joint{i+1}' for i in range(7)]
        joint_states_msgs.position = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.right_pub_joint.publish(joint_states_msgs)
        # self.rate.sleep()
        print("send joint control piper command")
    
    def joint_control_piper(self,j1,j2,j3,j4,j5,j6,gripper):
        joint_states_msgs = JointState()
        joint_states_msgs.header = Header()
        joint_states_msgs.header.stamp = rospy.Time.now()
        joint_states_msgs.name = [f'joint{i+1}' for i in range(7)]
        joint_states_msgs.position.append(j1)
        joint_states_msgs.position.append(j2)
        joint_states_msgs.position.append(j3)
        joint_states_msgs.position.append(j4)
        joint_states_msgs.position.append(j5)
        joint_states_msgs.position.append(j6)
        joint_states_msgs.position.append(gripper)
        self.pub_joint.publish(joint_states_msgs)
        # self.rate.sleep()
        print("send joint control piper command")
    
    def left_joint_control_piper(self,j1,j2,j3,j4,j5,j6,gripper):
        joint_states_msgs = JointState()
        joint_states_msgs.header = Header()
        joint_states_msgs.header.stamp = rospy.Time.now()
        joint_states_msgs.name = [f'joint{i+1}' for i in range(7)]
        joint_states_msgs.position.append(j1)
        joint_states_msgs.position.append(j2)
        joint_states_msgs.position.append(j3)
        joint_states_msgs.position.append(j4)
        joint_states_msgs.position.append(j5)
        joint_states_msgs.position.append(j6)
        joint_states_msgs.position.append(gripper)
        self.left_pub_joint.publish(joint_states_msgs)
        # self.rate.sleep()
        print("send joint control piper command")
        
    
    def right_joint_control_piper(self,j1,j2,j3,j4,j5,j6,gripper):
        joint_states_msgs = JointState()
        joint_states_msgs.header = Header()
        joint_states_msgs.header.stamp = rospy.Time.now()
        joint_states_msgs.name = [f'joint{i+1}' for i in range(7)]
        joint_states_msgs.position.append(j1)
        joint_states_msgs.position.append(j2)
        joint_states_msgs.position.append(j3)
        joint_states_msgs.position.append(j4)
        joint_states_msgs.position.append(j5)
        joint_states_msgs.position.append(j6)
        joint_states_msgs.position.append(gripper)
        self.right_pub_joint.publish(joint_states_msgs)
        # self.rate.sleep()
        print("send joint control piper command")
    
    
     
# test code
if __name__ == '__main__':
    # piper = PIPER() 
    rospy.init_node('control_piper_node', anonymous=True)
    # piper.control_piper(0.0,0.0,0.0,0.0,0.0,0.0,0.05)
    # 保持节点运行并监听外部程序的调用
    rospy.spin()
