import speech_recognition as sr
 
# 需要创建一个语音识别器实例，并使用默认的麦克风进行录音。
def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("请说话...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
        try:
            return recognizer.recognize_google(audio, language='zh-CN')
        except sr.UnknownValueError:
            print("Google Speech Recognition 无法理解音频")
        except sr.RequestError as e:
            print(f"从 Google Speech Recognition 服务请求错误; {e}")

# 接下来，我们需要解析识别到的文本，以确定用户想要触发哪个函数。这里我们使用简单的字符串匹配方法。
def parse_command(text):
    if "打开" in text:
        return "open"
    elif "关闭" in text:
        return "close"
    elif "复位" in text:
        return "reset"
    elif "开始遥操作" in text:
        return "start"
    else:
        return "unknown"

# 根据解析出的命令，我们将触发相应的函数。这里我们定义两个简单的示例函数：open_function 和 close_function。
def open_function():
    print("打开功能已触发")
 
def close_function():
    print("关闭功能已触发")

def init_pose():
    print("机械臂已复位")
    
def start_teleoperation():
    print("开始遥操作")
 
# 最后，我们将所有部分整合到主函数中。
def trigger_function(command):
    if command == "open":
        open_function()
    elif command == "close":
        close_function()
    elif command == "reset":
        init_pose()
    elif command == "start":
        start_teleoperation()
    else:
        print("未知命令")
        

def main():
    while True:
        text = recognize_speech()
        print("ppppppppn   =  ",  text)
        if text:
            command = parse_command(text)
            trigger_function(command)
 
if __name__ == "__main__":
    main()