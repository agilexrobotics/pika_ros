#!/bin/bash

cd ../../lib &&
./survive-cli