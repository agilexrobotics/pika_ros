// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PIPER_MSGS__MSG__PIPER_STATUS_MSG_HPP_
#define PIPER_MSGS__MSG__PIPER_STATUS_MSG_HPP_

#include "piper_msgs/msg/detail/piper_status_msg__struct.hpp"
#include "piper_msgs/msg/detail/piper_status_msg__builder.hpp"
#include "piper_msgs/msg/detail/piper_status_msg__traits.hpp"
#include "piper_msgs/msg/detail/piper_status_msg__type_support.hpp"

#endif  // PIPER_MSGS__MSG__PIPER_STATUS_MSG_HPP_
