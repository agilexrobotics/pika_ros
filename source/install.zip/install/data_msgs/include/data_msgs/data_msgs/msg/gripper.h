// generated from rosidl_generator_c/resource/idl.h.em
// with input from data_msgs:msg/Gripper.idl
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__GRIPPER_H_
#define DATA_MSGS__MSG__GRIPPER_H_

#include "data_msgs/msg/detail/gripper__struct.h"
#include "data_msgs/msg/detail/gripper__functions.h"
#include "data_msgs/msg/detail/gripper__type_support.h"

#endif  // DATA_MSGS__MSG__GRIPPER_H_
