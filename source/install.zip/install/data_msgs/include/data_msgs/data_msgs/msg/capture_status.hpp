// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DATA_MSGS__MSG__CAPTURE_STATUS_HPP_
#define DATA_MSGS__MSG__CAPTURE_STATUS_HPP_

#include "data_msgs/msg/detail/capture_status__struct.hpp"
#include "data_msgs/msg/detail/capture_status__builder.hpp"
#include "data_msgs/msg/detail/capture_status__traits.hpp"
#include "data_msgs/msg/detail/capture_status__type_support.hpp"

#endif  // DATA_MSGS__MSG__CAPTURE_STATUS_HPP_
