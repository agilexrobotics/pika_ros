#!/bin/bash

cd $HOME/pika_ros/install/libsurvive/bin &&
./survive-cli --force-calibrate
