// Auto-generated. Do not edit!

// (in-package data_tools.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class capture_serviceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.start = null;
      this.end = null;
      this.episodeIndex = null;
      this.datasetDir = null;
      this.instructions = null;
    }
    else {
      if (initObj.hasOwnProperty('start')) {
        this.start = initObj.start
      }
      else {
        this.start = false;
      }
      if (initObj.hasOwnProperty('end')) {
        this.end = initObj.end
      }
      else {
        this.end = false;
      }
      if (initObj.hasOwnProperty('episodeIndex')) {
        this.episodeIndex = initObj.episodeIndex
      }
      else {
        this.episodeIndex = 0;
      }
      if (initObj.hasOwnProperty('datasetDir')) {
        this.datasetDir = initObj.datasetDir
      }
      else {
        this.datasetDir = '';
      }
      if (initObj.hasOwnProperty('instructions')) {
        this.instructions = initObj.instructions
      }
      else {
        this.instructions = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type capture_serviceRequest
    // Serialize message field [start]
    bufferOffset = _serializer.bool(obj.start, buffer, bufferOffset);
    // Serialize message field [end]
    bufferOffset = _serializer.bool(obj.end, buffer, bufferOffset);
    // Serialize message field [episodeIndex]
    bufferOffset = _serializer.int32(obj.episodeIndex, buffer, bufferOffset);
    // Serialize message field [datasetDir]
    bufferOffset = _serializer.string(obj.datasetDir, buffer, bufferOffset);
    // Serialize message field [instructions]
    bufferOffset = _serializer.string(obj.instructions, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type capture_serviceRequest
    let len;
    let data = new capture_serviceRequest(null);
    // Deserialize message field [start]
    data.start = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [end]
    data.end = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [episodeIndex]
    data.episodeIndex = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [datasetDir]
    data.datasetDir = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [instructions]
    data.instructions = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.datasetDir);
    length += _getByteLength(object.instructions);
    return length + 14;
  }

  static datatype() {
    // Returns string type for a service object
    return 'data_tools/capture_serviceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a3a618d3a2ef5378ac04badb88d29ddd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool start
    bool end
    int32 episodeIndex
    string datasetDir
    string instructions
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new capture_serviceRequest(null);
    if (msg.start !== undefined) {
      resolved.start = msg.start;
    }
    else {
      resolved.start = false
    }

    if (msg.end !== undefined) {
      resolved.end = msg.end;
    }
    else {
      resolved.end = false
    }

    if (msg.episodeIndex !== undefined) {
      resolved.episodeIndex = msg.episodeIndex;
    }
    else {
      resolved.episodeIndex = 0
    }

    if (msg.datasetDir !== undefined) {
      resolved.datasetDir = msg.datasetDir;
    }
    else {
      resolved.datasetDir = ''
    }

    if (msg.instructions !== undefined) {
      resolved.instructions = msg.instructions;
    }
    else {
      resolved.instructions = ''
    }

    return resolved;
    }
};

class capture_serviceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type capture_serviceResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type capture_serviceResponse
    let len;
    let data = new capture_serviceResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'data_tools/capture_serviceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new capture_serviceResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: capture_serviceRequest,
  Response: capture_serviceResponse,
  md5sum() { return '8c4c92ec843b5ff951a7f1ba7d5cc0bf'; },
  datatype() { return 'data_tools/capture_service'; }
};
