// Auto-generated. Do not edit!

// (in-package data_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TeleopStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.teleop = null;
      this.wait = null;
      this.topics = null;
    }
    else {
      if (initObj.hasOwnProperty('teleop')) {
        this.teleop = initObj.teleop
      }
      else {
        this.teleop = false;
      }
      if (initObj.hasOwnProperty('wait')) {
        this.wait = initObj.wait
      }
      else {
        this.wait = false;
      }
      if (initObj.hasOwnProperty('topics')) {
        this.topics = initObj.topics
      }
      else {
        this.topics = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TeleopStatus
    // Serialize message field [teleop]
    bufferOffset = _serializer.bool(obj.teleop, buffer, bufferOffset);
    // Serialize message field [wait]
    bufferOffset = _serializer.bool(obj.wait, buffer, bufferOffset);
    // Serialize message field [topics]
    bufferOffset = _arraySerializer.string(obj.topics, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TeleopStatus
    let len;
    let data = new TeleopStatus(null);
    // Deserialize message field [teleop]
    data.teleop = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [wait]
    data.wait = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [topics]
    data.topics = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.topics.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'data_msgs/TeleopStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2ac5145f84a3217aa6897d1a1880e355';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool teleop
    bool wait
    string[] topics
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TeleopStatus(null);
    if (msg.teleop !== undefined) {
      resolved.teleop = msg.teleop;
    }
    else {
      resolved.teleop = false
    }

    if (msg.wait !== undefined) {
      resolved.wait = msg.wait;
    }
    else {
      resolved.wait = false
    }

    if (msg.topics !== undefined) {
      resolved.topics = msg.topics;
    }
    else {
      resolved.topics = []
    }

    return resolved;
    }
};

module.exports = TeleopStatus;
