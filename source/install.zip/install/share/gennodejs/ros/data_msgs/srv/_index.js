
"use strict";

let capture_service = require('./capture_service.js')

module.exports = {
  capture_service: capture_service,
};
