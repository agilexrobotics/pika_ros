
"use strict";

let CaptureService = require('./CaptureService.js')

module.exports = {
  CaptureService: CaptureService,
};
