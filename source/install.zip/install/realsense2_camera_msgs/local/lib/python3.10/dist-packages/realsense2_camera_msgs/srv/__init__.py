from realsense2_camera_msgs.srv._device_info import DeviceInfo  # noqa: F401
