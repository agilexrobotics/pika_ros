// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__MSG__METADATA_HPP_
#define REALSENSE2_CAMERA_MSGS__MSG__METADATA_HPP_

#include "realsense2_camera_msgs/msg/detail/metadata__struct.hpp"
#include "realsense2_camera_msgs/msg/detail/metadata__builder.hpp"
#include "realsense2_camera_msgs/msg/detail/metadata__traits.hpp"
#include "realsense2_camera_msgs/msg/detail/metadata__type_support.hpp"

#endif  // REALSENSE2_CAMERA_MSGS__MSG__METADATA_HPP_
