// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__MSG__EXTRINSICS_HPP_
#define REALSENSE2_CAMERA_MSGS__MSG__EXTRINSICS_HPP_

#include "realsense2_camera_msgs/msg/detail/extrinsics__struct.hpp"
#include "realsense2_camera_msgs/msg/detail/extrinsics__builder.hpp"
#include "realsense2_camera_msgs/msg/detail/extrinsics__traits.hpp"
#include "realsense2_camera_msgs/msg/detail/extrinsics__type_support.hpp"

#endif  // REALSENSE2_CAMERA_MSGS__MSG__EXTRINSICS_HPP_
