# 1 安装教程

librealsense 2.50.0 realsense-ros 2.3.2(ros1) (ros2是3.2.3)
先安装librealsense相机驱动，然后安装ros启动相机工具

# 2 安装librealsense

## 2.1 依赖

~~~bash
sudo apt-get install git libssl-dev libusb-1.0-0-dev pkg-config libgtk-3-dev libglfw3-dev libgl1-mesa-dev libglu1-mesa-dev 
~~~

~~~bash
git clone https://gitee.com/linClubs/librealsense-2.50.0.git
~~~


## 2.2 安装

运行Intel Realsense 的许可脚本 librealsense-2.50.0目录下
~~~
cd librealsense-2.50.0
./scripts/setup_udev_rules.sh
~~~

## 2.3 编译

~~~bash
mkdir build
cd build
cmake ..
make -j4
sudo make install
~~~

## 2.4 启动
打开终端
~~~bash
realsense_viewer
~~~

# 3 安装librealsense_ros

## 3.1 创建ros工作空间

已有工作空间直接看3.1

~~~bash
cd ~
mkdir -p catkin_ws/src
cd ~/catkin_ws/src
catkin_init_workspace
~~~

## 3.2 安装依赖ddynamic_reconfigure


将ddynamic_reconfigure放入工作空间下/src/进行编译

~~~bash
cd ~/catkin_ws/src
~~~

~~~bash
git clone https://gitee.com/linClubs/ddynamic_reconfigure.git
~~~

~~~bash
cd .. && catkin_make
~~~

## 3.3 安装librealsense_ros

将realsense_ros放到工作空间下/src

~~~bash
cd ~/catkin_ws/src
~~~

~~~bash
git clone https://gitee.com/linClubs/realsense-ros-2.3.2.git
~~~


~~~bash
cd .. && catkin_make
~~~

## 3.4 启动

如果报错，先看运行代码下面的改错

~~~bash
roslaunch realsense2_camera rs_rgbd.launch 
~~~

# 4 报错


1. 
~~~bash
sudo apt install ros-melodic-rgbd-launch
~~~

2. 

在realsense_ros下的CMakelists.txt添加opencv的查找，头文件，链接库文件

~~~cmake
# 寻找OpenCV库
find_package(OpenCV REQUIRED)
# 添加头文件
include_directories(${OpenCV_INCLUDE_DIRS})

add_executable(main main.cpp)

# 链接OpenCV库
target_link_libraries(main ${OpenCV_LIBS})
~~~





