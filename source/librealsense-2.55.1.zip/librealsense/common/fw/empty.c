int fw_empty; // avoid warnings about empty.o being an empty object
